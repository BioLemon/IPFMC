__version__ = '1.0.7'
__author__ = 'Haoyang Zhang'
__description__ = 'A tool for interpretable multi-omics integrated clustering.'

__all__ = ['direct', 'separate', 'analysis']

from . import *

